<?php
$email = 'slumberjer@gmail.com';
$mydate =  date('dmYhis');
echo $mydate.'-'.$email;
?>