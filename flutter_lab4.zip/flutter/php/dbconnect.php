<?php
$servername = "localhost";
$username 	= "ahmekncs_flutteruser";
$password 	= "Ahmed712724202";
$dbname 	= "ahmekncs_flutter";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>